const btnel = document.querySelector(".btn");

const closeiconel = document.querySelector(".close-icon");

const trailercontainerel = document.querySelector(".trailer-container");

const videoel = document.querySelector("video");


btnel.addEventListener("click", ()=>{
    trailercontainerel.classList.remove("active");
})
closeiconel.addEventListener("click", ()=>{
    trailercontainerel.classList.add("active");
    videoel.pause();
    videoel.currentTime = 0;
})